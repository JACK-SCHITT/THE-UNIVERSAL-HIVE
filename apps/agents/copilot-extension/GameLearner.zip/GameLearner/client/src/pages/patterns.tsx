import MobileHeader from "@/components/mobile-header";
import NavigationTabs from "@/components/navigation-tabs";
import TouchVisualization from "@/components/touch-visualization";
import FloatingActionButton from "@/components/floating-action-button";

export default function Patterns() {
  return (
    <>
      <MobileHeader status="Learning" />
      <NavigationTabs activeTab="patterns" />
      
      <main className="p-4 space-y-6 pb-20">
        <TouchVisualization showAdvanced={true} />
      </main>

      <FloatingActionButton />
    </>
  );
}
