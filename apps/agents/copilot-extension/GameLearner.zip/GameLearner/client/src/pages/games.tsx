import MobileHeader from "@/components/mobile-header";
import NavigationTabs from "@/components/navigation-tabs";
import GameLibrary from "@/components/game-library";
import FloatingActionButton from "@/components/floating-action-button";

export default function Games() {
  return (
    <>
      <MobileHeader status="Active" />
      <NavigationTabs activeTab="games" />
      
      <main className="p-4 space-y-6 pb-20">
        <GameLibrary showAddButton={true} />
      </main>

      <FloatingActionButton />
    </>
  );
}
