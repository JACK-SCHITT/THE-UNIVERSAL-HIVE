import { useState, useEffect } from "react";
import MobileHeader from "@/components/mobile-header";
import NavigationTabs from "@/components/navigation-tabs";
import AutoClickerControl from "@/components/auto-clicker-control";
import TouchVisualization from "@/components/touch-visualization";
import LearningStatus from "@/components/learning-status";
import GameLibrary from "@/components/game-library";
import AccountManager from "@/components/account-manager";
import FloatingActionButton from "@/components/floating-action-button";
import SettingsModal from "@/components/settings-modal";

export default function Dashboard() {
  const [showSettings, setShowSettings] = useState(false);
  const [learningStatus, setLearningStatus] = useState("Learning");

  // WebSocket connection for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("WebSocket connected");
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("WebSocket message:", data);
        
        switch (data.type) {
          case 'learning_started':
            setLearningStatus("Learning");
            break;
          case 'learning_progress_updated':
            if (data.data.learningProgress >= 100) {
              setLearningStatus("Active");
            }
            break;
          case 'auto_clicker_started':
            setLearningStatus("Auto-clicking");
            break;
          case 'auto_clicker_stopped':
            setLearningStatus("Learning");
            break;
          case 'emergency_stop_activated':
            setLearningStatus("Stopped");
            break;
        }
      } catch (error) {
        console.error("Failed to parse WebSocket message:", error);
      }
    };

    socket.onclose = () => {
      console.log("WebSocket disconnected");
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    return () => {
      socket.close();
    };
  }, []);

  return (
    <>
      <MobileHeader 
        status={learningStatus} 
        onSettingsClick={() => setShowSettings(true)} 
      />
      <NavigationTabs activeTab="dashboard" />
      
      <main className="p-4 space-y-6 pb-20">
        <AutoClickerControl />
        <TouchVisualization />
        <LearningStatus />
        <GameLibrary />
        <AccountManager />
      </main>

      <FloatingActionButton onQuickSettings={() => setShowSettings(true)} />
      
      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
      />
    </>
  );
}
