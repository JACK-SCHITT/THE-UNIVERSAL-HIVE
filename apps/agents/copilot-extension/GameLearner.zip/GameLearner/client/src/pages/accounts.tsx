import MobileHeader from "@/components/mobile-header";
import NavigationTabs from "@/components/navigation-tabs";
import AccountManager from "@/components/account-manager";
import FloatingActionButton from "@/components/floating-action-button";

export default function Accounts() {
  return (
    <>
      <MobileHeader status="Active" />
      <NavigationTabs activeTab="accounts" />
      
      <main className="p-4 space-y-6 pb-20">
        <AccountManager showAdvanced={true} />
      </main>

      <FloatingActionButton />
    </>
  );
}
