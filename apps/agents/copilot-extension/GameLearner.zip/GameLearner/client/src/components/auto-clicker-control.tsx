import { useState } from "react";
import { MousePointer, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AutoClickerControl() {
  const [speed, setSpeed] = useState(3);
  const [repeatCount, setRepeatCount] = useState<number | null>(100);
  const [targetX, setTargetX] = useState<number>(0);
  const [targetY, setTargetY] = useState<number>(0);
  const [isInfinite, setIsInfinite] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: activeSession } = useQuery({
    queryKey: ['/api/auto-clicker/active'],
    refetchInterval: 1000,
  });

  const startClickerMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/auto-clicker/start', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-clicker/active'] });
      toast({ title: "Auto-clicker started successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to start auto-clicker", description: error.message, variant: "destructive" });
    },
  });

  const stopClickerMutation = useMutation({
    mutationFn: () => apiRequest('/api/auto-clicker/stop', { method: 'POST' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-clicker/active'] });
      toast({ title: "Auto-clicker stopped" });
    },
    onError: (error) => {
      toast({ title: "Failed to stop auto-clicker", description: error.message, variant: "destructive" });
    },
  });

  const handleStartClicking = () => {
    if (!targetX || !targetY) {
      toast({ title: "Please set target coordinates first", variant: "destructive" });
      return;
    }

    startClickerMutation.mutate({
      speed,
      repeatCount: isInfinite ? null : repeatCount,
      targetX,
      targetY,
      gameId: null, // Can be set based on selected game
    });
  };

  const handleStopClicking = () => {
    stopClickerMutation.mutate();
  };

  const handleSetInfinite = () => {
    setIsInfinite(!isInfinite);
    if (!isInfinite) {
      setRepeatCount(null);
    } else {
      setRepeatCount(100);
    }
  };

  const speedTexts = [
    '', '1x - Human Speed', '2x - Slightly Faster', '3x - Fast',
    '4x - Very Fast', '5x - Rapid', '6x - Super Fast', '7x - Lightning',
    '8x - Extreme', '9x - Superhuman', '10x - 20x Human Speed'
  ];

  const isActive = activeSession?.isActive || false;

  return (
    <Card data-testid="auto-clicker-control">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <MousePointer className="w-5 h-5 text-primary mr-2" />
            Auto-Clicker Control
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Active</span>
            <Switch 
              checked={isActive} 
              disabled
              data-testid="clicker-toggle"
            />
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div>
          <Label className="block text-sm font-medium mb-2">Click Speed (1-10)</Label>
          <div className="flex items-center space-x-3">
            <span className="text-xs text-muted-foreground">1x</span>
            <input
              type="range"
              min="1"
              max="10"
              value={speed}
              onChange={(e) => setSpeed(parseInt(e.target.value))}
              className="flex-1 speed-slider"
              data-testid="speed-slider"
            />
            <span className="text-xs text-muted-foreground">20x</span>
          </div>
          <div className="text-center mt-1">
            <span className="text-sm text-primary font-medium" data-testid="speed-display">
              {speedTexts[speed]}
            </span>
          </div>
        </div>

        <div>
          <Label className="block text-sm font-medium mb-2">Target Coordinates</Label>
          <div className="flex space-x-2">
            <Input
              type="number"
              placeholder="X"
              value={targetX || ''}
              onChange={(e) => setTargetX(parseInt(e.target.value) || 0)}
              data-testid="target-x"
            />
            <Input
              type="number"
              placeholder="Y"
              value={targetY || ''}
              onChange={(e) => setTargetY(parseInt(e.target.value) || 0)}
              data-testid="target-y"
            />
          </div>
        </div>

        <div>
          <Label className="block text-sm font-medium mb-2">Repeat Count</Label>
          <div className="flex space-x-2">
            <Input
              type="number"
              min="1"
              placeholder="100"
              value={isInfinite ? '' : (repeatCount || '')}
              onChange={(e) => setRepeatCount(parseInt(e.target.value) || null)}
              disabled={isInfinite}
              data-testid="repeat-count"
            />
            <Button
              variant={isInfinite ? "default" : "secondary"}
              onClick={handleSetInfinite}
              className="px-4"
              data-testid="infinite-button"
            >
              ∞
            </Button>
          </div>
        </div>

        <div className="flex space-x-2">
          <Button
            onClick={handleStartClicking}
            disabled={isActive || startClickerMutation.isPending}
            className="flex-1"
            data-testid="start-clicker"
          >
            <Play className="w-4 h-4 mr-2" />
            Start
          </Button>
          <Button
            onClick={handleStopClicking}
            disabled={!isActive || stopClickerMutation.isPending}
            variant="destructive"
            className="flex-1"
            data-testid="stop-clicker"
          >
            <Square className="w-4 h-4 mr-2" />
            Stop
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
