import { useState } from "react";
import { Gamepad2, Plus, Play, Trash2, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertGameSchema, type InsertGame } from "@shared/schema";

interface GameLibraryProps {
  showAddButton?: boolean;
}

export default function GameLibrary({ showAddButton = false }: GameLibraryProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: games = [], isLoading } = useQuery({
    queryKey: ['/api/games'],
  });

  const form = useForm<InsertGame>({
    resolver: zodResolver(insertGameSchema),
    defaultValues: {
      name: '',
      url: '',
      type: 'mobile',
      status: 'inactive',
      learningProgress: 0,
      patterns: [],
    },
  });

  const createGameMutation = useMutation({
    mutationFn: (data: InsertGame) => apiRequest('/api/games', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/games'] });
      toast({ title: "Game added successfully" });
      setShowAddDialog(false);
      form.reset();
    },
    onError: (error) => {
      toast({ title: "Failed to add game", description: error.message, variant: "destructive" });
    },
  });

  const deleteGameMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/games/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/games'] });
      toast({ title: "Game deleted successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to delete game", description: error.message, variant: "destructive" });
    },
  });

  const startLearningMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/games/${id}/start-learning`, { method: 'POST' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/games'] });
      toast({ title: "Learning started for game" });
    },
    onError: (error) => {
      toast({ title: "Failed to start learning", description: error.message, variant: "destructive" });
    },
  });

  const onSubmit = (data: InsertGame) => {
    createGameMutation.mutate(data);
  };

  const handleLaunchGame = (game: any) => {
    if (game.status === 'inactive') {
      startLearningMutation.mutate(game.id);
    } else {
      window.open(game.url, '_blank');
      toast({ title: `Opening ${game.name}...` });
    }
  };

  const handleDeleteGame = (gameId: string) => {
    if (confirm('Are you sure you want to delete this game?')) {
      deleteGameMutation.mutate(gameId);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'learning': return 'bg-amber-500 learning-pulse';
      case 'inactive': return 'bg-red-500';
      default: return 'bg-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Ready';
      case 'learning': return 'Learning';
      case 'inactive': return 'Setup Required';
      default: return 'Unknown';
    }
  };

  const getGameIcon = (type: string) => {
    return 'fas fa-gamepad'; // Default icon
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="text-center text-muted-foreground">Loading games...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="game-library">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Gamepad2 className="w-5 h-5 text-primary mr-2" />
          Game Library
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {games.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            No games added yet
          </div>
        ) : (
          games.map((game: any) => (
            <div
              key={game.id}
              className="flex items-center justify-between p-3 bg-muted rounded-lg"
              data-testid={`game-item-${game.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center`}>
                  <Gamepad2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-medium" data-testid={`game-name-${game.id}`}>
                    {game.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {game.status === 'learning' 
                      ? `Learning: ${game.learningProgress}% complete`
                      : game.lastPlayed 
                        ? `Last played: ${new Date(game.lastPlayed).toLocaleDateString()}`
                        : 'Never played'
                    }
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div 
                  className={`w-2 h-2 rounded-full ${getStatusColor(game.status)}`}
                  data-testid={`game-status-${game.id}`}
                />
                <Button
                  size="sm"
                  onClick={() => handleLaunchGame(game)}
                  variant={game.status === 'active' ? 'default' : 'secondary'}
                  data-testid={`launch-game-${game.id}`}
                >
                  {game.status === 'active' ? (
                    <>
                      <Play className="w-3 h-3 mr-1" />
                      Launch
                    </>
                  ) : (
                    <>
                      <Settings className="w-3 h-3 mr-1" />
                      {getStatusText(game.status)}
                    </>
                  )}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleDeleteGame(game.id)}
                  data-testid={`delete-game-${game.id}`}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))
        )}

        {showAddButton && (
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                className="w-full" 
                data-testid="add-game-button"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add New Game
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Game</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Game Name</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="Enter game name"
                            data-testid="game-name-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Game URL</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="https://game-url.com"
                            data-testid="game-url-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Game Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="game-type-select">
                              <SelectValue placeholder="Select game type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="mobile">Mobile Game</SelectItem>
                            <SelectItem value="web">Web Game</SelectItem>
                            <SelectItem value="idle">Idle Game</SelectItem>
                            <SelectItem value="rpg">RPG Game</SelectItem>
                            <SelectItem value="strategy">Strategy Game</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex space-x-2">
                    <Button 
                      type="submit" 
                      disabled={createGameMutation.isPending}
                      className="flex-1"
                      data-testid="submit-game"
                    >
                      Add Game
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowAddDialog(false)}
                      className="flex-1"
                      data-testid="cancel-add-game"
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
}
