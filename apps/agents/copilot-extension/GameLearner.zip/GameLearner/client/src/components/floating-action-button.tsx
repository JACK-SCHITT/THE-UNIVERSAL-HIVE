import { Hand, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface FloatingActionButtonProps {
  onQuickSettings?: () => void;
}

export default function FloatingActionButton({ onQuickSettings }: FloatingActionButtonProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const emergencyStopMutation = useMutation({
    mutationFn: () => apiRequest('/api/auto-clicker/emergency-stop', { method: 'POST' }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-clicker/active'] });
      toast({ 
        title: "Emergency Stop Activated", 
        description: `Stopped ${data.stoppedSessions?.length || 0} active sessions`,
        variant: "destructive" 
      });
    },
    onError: (error) => {
      toast({ title: "Emergency stop failed", description: error.message, variant: "destructive" });
    },
  });

  const handleEmergencyStop = () => {
    emergencyStopMutation.mutate();
  };

  const handleQuickSettings = () => {
    if (onQuickSettings) {
      onQuickSettings();
    } else {
      toast({ title: "Quick Settings", description: "Settings panel opened" });
    }
  };

  return (
    <div className="fixed bottom-4 right-4 flex flex-col space-y-2" data-testid="floating-actions">
      <Button
        size="lg"
        variant="destructive"
        className="w-12 h-12 rounded-full shadow-lg"
        onClick={handleEmergencyStop}
        disabled={emergencyStopMutation.isPending}
        title="Emergency Stop"
        data-testid="emergency-stop-button"
      >
        <Hand className="w-5 h-5" />
      </Button>
      
      <Button
        size="lg"
        className="w-12 h-12 rounded-full shadow-lg"
        onClick={handleQuickSettings}
        title="Quick Settings"
        data-testid="quick-settings-button"
      >
        <SlidersHorizontal className="w-5 h-5" />
      </Button>
    </div>
  );
}
