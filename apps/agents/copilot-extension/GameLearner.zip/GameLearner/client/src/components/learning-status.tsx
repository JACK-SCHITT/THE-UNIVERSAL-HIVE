import { useEffect, useState } from "react";
import { Brain } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";

export default function LearningStatus() {
  const [buttonRecognition, setButtonRecognition] = useState(87);
  const [patternOptimization, setPatternOptimization] = useState(62);
  const [gameStateAnalysis, setGameStateAnalysis] = useState(94);
  
  const { data: learningData = [] } = useQuery({
    queryKey: ['/api/learning-data'],
    refetchInterval: 5000,
  });

  // Simulate learning progress updates
  useEffect(() => {
    const interval = setInterval(() => {
      setButtonRecognition(prev => Math.min(100, prev + Math.random() * 2));
      setPatternOptimization(prev => Math.min(100, prev + Math.random() * 1.5));
      setGameStateAnalysis(prev => Math.min(100, prev + Math.random() * 0.5));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const recentDiscoveries = [
    "Detected new 'Collect Reward' button pattern",
    "Optimized tap sequence for menu navigation", 
    "Learned shop interaction timing",
    "Identified loading screen patterns",
    "Improved button click accuracy"
  ];

  return (
    <Card data-testid="learning-status">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Brain className="w-5 h-5 text-primary mr-2" />
          Learning Progress
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Button Recognition</span>
              <span className="text-sm text-muted-foreground" data-testid="button-recognition-percent">
                {Math.round(buttonRecognition)}%
              </span>
            </div>
            <Progress 
              value={buttonRecognition} 
              className="h-2" 
              data-testid="button-recognition-progress"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Pattern Optimization</span>
              <span className="text-sm text-muted-foreground" data-testid="pattern-optimization-percent">
                {Math.round(patternOptimization)}%
              </span>
            </div>
            <Progress 
              value={patternOptimization} 
              className="h-2"
              data-testid="pattern-optimization-progress"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Game State Analysis</span>
              <span className="text-sm text-muted-foreground" data-testid="game-state-percent">
                {Math.round(gameStateAnalysis)}%
              </span>
            </div>
            <Progress 
              value={gameStateAnalysis} 
              className="h-2"
              data-testid="game-state-progress" 
            />
          </div>
        </div>

        <div className="p-3 bg-muted rounded-lg">
          <h3 className="text-sm font-medium mb-2">Recent Discoveries</h3>
          <div className="space-y-1 text-xs text-muted-foreground">
            {recentDiscoveries.slice(0, 3).map((discovery, index) => (
              <div key={index} data-testid={`discovery-${index}`}>
                • {discovery}
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center" data-testid="learning-data-count">
          {learningData.length} learning data points collected
        </div>
      </CardContent>
    </Card>
  );
}
