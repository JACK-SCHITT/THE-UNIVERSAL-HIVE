import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const [detectionSensitivity, setDetectionSensitivity] = useState(7);
  const [learningRate, setLearningRate] = useState("balanced");
  const [autoRetry, setAutoRetry] = useState(true);
  const [autoBackup, setAutoBackup] = useState(true);
  
  const { toast } = useToast();

  const handleSaveSettings = () => {
    // In a real app, save settings to backend
    toast({ title: "Settings saved successfully" });
    onClose();
  };

  const handleResetSettings = () => {
    setDetectionSensitivity(7);
    setLearningRate("balanced");
    setAutoRetry(true);
    setAutoBackup(true);
    toast({ title: "Settings reset to defaults" });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="settings-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Advanced Settings
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              data-testid="close-settings"
            >
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 max-h-96 overflow-y-auto">
          <div>
            <Label className="block text-sm font-medium mb-2">
              Detection Sensitivity: {detectionSensitivity}
            </Label>
            <input
              type="range"
              min="1"
              max="10"
              value={detectionSensitivity}
              onChange={(e) => setDetectionSensitivity(parseInt(e.target.value))}
              className="w-full speed-slider"
              data-testid="sensitivity-slider"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Low</span>
              <span>High</span>
            </div>
          </div>
          
          <div>
            <Label className="block text-sm font-medium mb-2">Learning Rate</Label>
            <Select value={learningRate} onValueChange={setLearningRate}>
              <SelectTrigger data-testid="learning-rate-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conservative">Conservative</SelectItem>
                <SelectItem value="balanced">Balanced</SelectItem>
                <SelectItem value="aggressive">Aggressive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="block text-sm font-medium mb-2">Error Handling</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="auto-retry"
                  checked={autoRetry}
                  onCheckedChange={setAutoRetry}
                  data-testid="auto-retry-checkbox"
                />
                <Label htmlFor="auto-retry" className="text-sm">
                  Auto-retry failed actions
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="auto-backup"
                  checked={autoBackup}
                  onCheckedChange={setAutoBackup}
                  data-testid="auto-backup-checkbox"
                />
                <Label htmlFor="auto-backup" className="text-sm">
                  Backup patterns automatically
                </Label>
              </div>
            </div>
          </div>

          <div className="p-3 bg-muted rounded-lg">
            <h4 className="text-sm font-medium mb-2">Performance Stats</h4>
            <div className="space-y-1 text-xs text-muted-foreground">
              <div>CPU Usage: Low (12%)</div>
              <div>Memory Usage: 45MB</div>
              <div>Active Sessions: 0</div>
            </div>
          </div>
        </div>
        
        <div className="flex space-x-2 pt-4 border-t border-border">
          <Button 
            onClick={handleResetSettings}
            variant="outline"
            className="flex-1"
            data-testid="reset-settings"
          >
            Reset
          </Button>
          <Button 
            onClick={handleSaveSettings}
            className="flex-1"
            data-testid="save-settings"
          >
            Save Settings
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
