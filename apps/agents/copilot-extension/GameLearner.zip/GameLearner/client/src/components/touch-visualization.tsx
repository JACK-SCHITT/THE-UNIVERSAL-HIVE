import { useState, useRef, useEffect } from "react";
import { Crosshair, Play, Square, Edit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TouchVisualizationProps {
  showAdvanced?: boolean;
}

interface TouchPoint {
  x: number;
  y: number;
  timestamp: number;
}

export default function TouchVisualization({ showAdvanced = false }: TouchVisualizationProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [touchPoints, setTouchPoints] = useState<TouchPoint[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: patterns = [] } = useQuery({
    queryKey: ['/api/touch-patterns'],
  });

  const recordLearningDataMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/learning-data', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onError: (error) => {
      console.error("Failed to record learning data:", error);
    },
  });

  const createPatternMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/touch-patterns', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/touch-patterns'] });
      toast({ title: "Touch pattern saved successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to save pattern", description: error.message, variant: "destructive" });
    },
  });

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isRecording) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const touchPoint: TouchPoint = {
      x,
      y,
      timestamp: Date.now(),
    };

    setTouchPoints(prev => [...prev, touchPoint]);

    // Record learning data
    recordLearningDataMutation.mutate({
      x: e.clientX,
      y: e.clientY,
      target: 'touch_visualization',
      context: 'pattern_recording',
      gameId: null,
    });

    // Create visual indicator
    createTouchIndicator(x, y);
  };

  const createTouchIndicator = (x: number, y: number) => {
    if (!canvasRef.current) return;

    const indicator = document.createElement('div');
    indicator.className = 'touch-indicator';
    indicator.style.left = `${x - 10}px`;
    indicator.style.top = `${y - 10}px`;
    
    canvasRef.current.appendChild(indicator);
    
    setTimeout(() => {
      if (canvasRef.current && indicator.parentNode) {
        canvasRef.current.removeChild(indicator);
      }
    }, 1000);
  };

  const handleRecordPattern = () => {
    if (isRecording) {
      // Stop recording and save pattern
      if (touchPoints.length > 0) {
        const sequence = touchPoints.map((point, index) => ({
          x: point.x,
          y: point.y,
          delay: index > 0 ? point.timestamp - touchPoints[index - 1].timestamp : 0,
        }));

        createPatternMutation.mutate({
          name: `Pattern ${new Date().toLocaleTimeString()}`,
          sequence,
          confidence: 75,
          gameId: null,
        });
      }
      setIsRecording(false);
      setTouchPoints([]);
    } else {
      // Start recording
      setIsRecording(true);
      setTouchPoints([]);
      toast({ title: "Recording started", description: "Tap on the canvas to record touch points" });
    }
  };

  const handlePlayPattern = async () => {
    if (touchPoints.length === 0 && patterns.length === 0) {
      toast({ title: "No pattern to play", description: "Record a pattern first", variant: "destructive" });
      return;
    }

    setIsPlaying(true);
    
    const sequence = touchPoints.length > 0 
      ? touchPoints 
      : patterns[0]?.sequence || [];

    // Simulate pattern playback
    for (let i = 0; i < sequence.length; i++) {
      const point = sequence[i];
      await new Promise(resolve => setTimeout(resolve, point.delay || 500));
      createTouchIndicator(point.x, point.y);
    }

    setIsPlaying(false);
    toast({ title: "Pattern playback completed" });
  };

  const handleEditPattern = () => {
    toast({ title: "Pattern editing", description: "Advanced pattern editing coming soon" });
  };

  return (
    <Card data-testid="touch-visualization">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Crosshair className="w-5 h-5 text-primary mr-2" />
          Touch Pattern Visualization
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div
          ref={canvasRef}
          onClick={handleCanvasClick}
          className="relative bg-muted rounded-lg h-48 overflow-hidden cursor-crosshair"
          data-testid="touch-canvas"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg" />
          
          {/* Display recorded touch points */}
          {touchPoints.map((point, index) => (
            <div
              key={index}
              className="absolute w-3 h-3 bg-primary rounded-full border-2 border-primary-foreground transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: point.x, top: point.y }}
              data-testid={`touch-point-${index}`}
            />
          ))}
          
          <div className="absolute bottom-2 left-2 text-xs text-muted-foreground">
            <Crosshair className="w-3 h-3 inline mr-1" />
            {isRecording 
              ? `Recording: ${touchPoints.length} touch points`
              : `${touchPoints.length} touch points recorded`
            }
          </div>
        </div>

        <div className="flex space-x-2">
          <Button
            onClick={handleRecordPattern}
            variant={isRecording ? "destructive" : "secondary"}
            className="flex-1"
            data-testid="record-button"
          >
            {isRecording ? (
              <>
                <Square className="w-4 h-4 mr-2" />
                Stop Recording
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Record
              </>
            )}
          </Button>
          
          <Button
            onClick={handlePlayPattern}
            disabled={isPlaying}
            variant="secondary"
            className="flex-1"
            data-testid="play-button"
          >
            <Play className="w-4 h-4 mr-2" />
            Replay
          </Button>
          
          <Button
            onClick={handleEditPattern}
            variant="secondary"
            className="flex-1"
            data-testid="edit-button"
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
        </div>

        {showAdvanced && patterns.length > 0 && (
          <div className="mt-4 space-y-2">
            <h3 className="text-sm font-medium">Saved Patterns</h3>
            {patterns.map((pattern: any) => (
              <div
                key={pattern.id}
                className="flex items-center justify-between p-2 bg-muted rounded"
                data-testid={`pattern-${pattern.id}`}
              >
                <span className="text-sm">{pattern.name}</span>
                <span className="text-xs text-muted-foreground">
                  {pattern.sequence?.length || 0} points
                </span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
