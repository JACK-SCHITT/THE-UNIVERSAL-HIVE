import { Link, useLocation } from "wouter";
import { Home, Gamepad2, Brain, Users } from "lucide-react";

interface NavigationTabsProps {
  activeTab?: string;
}

export default function NavigationTabs({ activeTab }: NavigationTabsProps) {
  const [location] = useLocation();
  
  const getActiveTab = () => {
    if (activeTab) return activeTab;
    switch (location) {
      case '/': return 'dashboard';
      case '/games': return 'games';
      case '/patterns': return 'patterns';
      case '/accounts': return 'accounts';
      default: return 'dashboard';
    }
  };

  const currentTab = getActiveTab();

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, path: '/' },
    { id: 'games', label: 'Games', icon: Gamepad2, path: '/games' },
    { id: 'patterns', label: 'Patterns', icon: Brain, path: '/patterns' },
    { id: 'accounts', label: 'Accounts', icon: Users, path: '/accounts' },
  ];

  return (
    <nav className="bg-card border-b border-border sticky top-16 z-40" data-testid="navigation-tabs">
      <div className="flex">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;
          
          return (
            <Link key={tab.id} href={tab.path}>
              <button
                className={`flex-1 py-3 px-4 text-center text-sm font-medium transition-colors ${
                  isActive 
                    ? 'bg-primary text-primary-foreground' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                data-testid={`tab-${tab.id}`}
              >
                <Icon className="w-4 h-4 mb-1 mx-auto" />
                {tab.label}
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
