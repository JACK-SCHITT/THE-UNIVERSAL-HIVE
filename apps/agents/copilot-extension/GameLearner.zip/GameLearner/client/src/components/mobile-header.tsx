import { Bot, Settings, Cog } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MobileHeaderProps {
  status?: string;
  onSettingsClick?: () => void;
}

export default function MobileHeader({ status = "Learning", onSettingsClick }: MobileHeaderProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'learning': return 'bg-learning-pulse';
      case 'active': return 'bg-green-500';
      case 'auto-clicking': return 'bg-blue-500';
      case 'stopped': return 'bg-red-500';
      default: return 'bg-muted-foreground';
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border" data-testid="mobile-header">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Bot className="w-4 h-4 text-primary-foreground" />
          </div>
          <h1 className="text-lg font-semibold" data-testid="app-title">GameBot Pro</h1>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full learning-pulse ${getStatusColor(status)}`} data-testid="status-indicator" />
          <span className="text-xs text-muted-foreground" data-testid="status-text">{status}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={onSettingsClick}
            className="p-2 rounded-lg hover:bg-muted"
            data-testid="settings-button"
          >
            <Cog className="w-4 h-4 text-muted-foreground" />
          </Button>
        </div>
      </div>
    </header>
  );
}
