import { useState } from "react";
import { Users, Plus, Shield, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertAccountSchema, type InsertAccount } from "@shared/schema";

interface AccountManagerProps {
  showAdvanced?: boolean;
}

export default function AccountManager({ showAdvanced = false }: AccountManagerProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ['/api/accounts'],
  });

  const form = useForm<InsertAccount>({
    resolver: zodResolver(insertAccountSchema),
    defaultValues: {
      email: '',
      password: '',
      provider: 'gmail',
      linkedGames: [],
      isActive: true,
    },
  });

  const createAccountMutation = useMutation({
    mutationFn: (data: InsertAccount) => apiRequest('/api/accounts', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      toast({ title: "Account added successfully" });
      setShowAddDialog(false);
      form.reset();
    },
    onError: (error) => {
      toast({ title: "Failed to add account", description: error.message, variant: "destructive" });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/accounts/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      toast({ title: "Account deleted successfully" });
    },
    onError: (error) => {
      toast({ title: "Failed to delete account", description: error.message, variant: "destructive" });
    },
  });

  const onSubmit = (data: InsertAccount) => {
    createAccountMutation.mutate(data);
  };

  const handleDeleteAccount = (accountId: string) => {
    if (confirm('Are you sure you want to delete this account? This action cannot be undone.')) {
      deleteAccountMutation.mutate(accountId);
    }
  };

  const handleEditAccount = (accountId: string) => {
    toast({ title: "Account editing", description: "Advanced account editing coming soon" });
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="text-center text-muted-foreground">Loading accounts...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="account-manager">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Users className="w-5 h-5 text-primary mr-2" />
          Account Manager
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-3">
        {accounts.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            No email accounts added
          </div>
        ) : (
          accounts.map((account: any) => (
            <div
              key={account.id}
              className="flex items-center justify-between p-3 bg-muted rounded-lg"
              data-testid={`account-item-${account.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Users className="w-4 h-4 text-primary-foreground" />
                </div>
                <div>
                  <div className="font-medium text-sm" data-testid={`account-email-${account.id}`}>
                    {account.email}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {account.linkedGames?.length || 0} games linked
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-green-500" title="Encrypted" />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleEditAccount(account.id)}
                  data-testid={`edit-account-${account.id}`}
                >
                  <Edit className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleDeleteAccount(account.id)}
                  data-testid={`delete-account-${account.id}`}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))
        )}

        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="w-full" 
              data-testid="add-account-button"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Email Account
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Email Account</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="email"
                          placeholder="your-email@gmail.com"
                          data-testid="email-input"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="password"
                          placeholder="Enter password"
                          data-testid="password-input"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="provider"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Provider</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="provider-select">
                            <SelectValue placeholder="Select provider" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="gmail">Gmail</SelectItem>
                          <SelectItem value="yahoo">Yahoo</SelectItem>
                          <SelectItem value="outlook">Outlook</SelectItem>
                          <SelectItem value="icloud">iCloud</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex space-x-2">
                  <Button 
                    type="submit" 
                    disabled={createAccountMutation.isPending}
                    className="flex-1"
                    data-testid="submit-account"
                  >
                    Add Account
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowAddDialog(false)}
                    className="flex-1"
                    data-testid="cancel-add-account"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {showAdvanced && (
          <div className="mt-4 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
            <div className="flex items-center text-amber-500 text-sm">
              <Shield className="w-4 h-4 mr-2" />
              All credentials encrypted with AES-256
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
