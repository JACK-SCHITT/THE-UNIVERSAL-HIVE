import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Router, Route, Switch } from "wouter";
import { queryClient } from "@/lib/queryClient";

import Dashboard from "@/pages/dashboard";
import Games from "@/pages/games";
import Patterns from "@/pages/patterns";
import Accounts from "@/pages/accounts";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-background text-foreground mobile-optimized">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/games" component={Games} />
            <Route path="/patterns" component={Patterns} />
            <Route path="/accounts" component={Accounts} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
