import { QueryClient } from "@tanstack/react-query";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: async ({ queryKey }) => {
        const url = queryKey[0] as string;
        const res = await fetch(url);
        if (!res.ok) {
          if (res.status >= 500) {
            throw new Error(`Server error: ${res.status}`);
          }
          if (res.status >= 400) {
            const errorData = await res.json().catch(() => ({ message: 'Bad request' }));
            throw new Error(errorData.message || `Client error: ${res.status}`);
          }
        }
        return res.json();
      },
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: (failureCount, error) => {
        if ((error as Error).message.includes('Client error')) {
          return false;
        }
        return failureCount < 3;
      },
    },
  },
});

export const apiRequest = async (url: string, options: RequestInit = {}) => {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'Network error' }));
    throw new Error(errorData.message || `HTTP error: ${response.status}`);
  }

  return response.json();
};

export { queryClient };
