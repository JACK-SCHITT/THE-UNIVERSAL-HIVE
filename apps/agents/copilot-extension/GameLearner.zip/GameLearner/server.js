const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files
app.use(express.static('.'));

// API Routes
app.post('/api/games', (req, res) => {
    // Handle game addition
    const { name, url, type } = req.body;
    
    // In a real app, save to database
    const game = {
        id: Date.now(),
        name,
        url,
        type,
        status: 'inactive',
        learningProgress: 0,
        addedDate: new Date().toISOString()
    };
    
    res.json({ success: true, game });
});

app.post('/api/learning/record', (req, res) => {
    // Handle learning data recording
    const { x, y, target, timestamp, context } = req.body;
    
    // In a real app, process and save learning data
    console.log('Learning data recorded:', { x, y, target, timestamp, context });
    
    res.json({ success: true });
});

app.post('/api/autoclicker/start', (req, res) => {
    // Handle auto clicker start
    const { x, y, speed, repeatCount } = req.body;
    
    console.log('Auto clicker started:', { x, y, speed, repeatCount });
    
    res.json({ success: true, message: 'Auto clicker started' });
});

app.post('/api/autoclicker/stop', (req, res) => {
    // Handle auto clicker stop
    console.log('Auto clicker stopped');
    
    res.json({ success: true, message: 'Auto clicker stopped' });
});

app.post('/api/tasks', (req, res) => {
    // Handle task creation
    const { name, game, time, description } = req.body;
    
    const task = {
        id: Date.now(),
        name,
        game,
        time,
        description,
        completed: false,
        createdDate: new Date().toISOString()
    };
    
    res.json({ success: true, task });
});

app.post('/api/tasks/:id/execute', (req, res) => {
    // Handle task execution
    const { id } = req.params;
    
    console.log(`Executing task ${id}`);
    
    // Simulate task execution
    setTimeout(() => {
        console.log(`Task ${id} completed`);
    }, 3000);
    
    res.json({ success: true, message: 'Task execution started' });
});

app.post('/api/emails', (req, res) => {
    // Handle email account addition
    const { address, password, provider } = req.body;
    
    // In a real app, encrypt password and validate credentials
    const emailAccount = {
        id: Date.now(),
        address,
        provider,
        status: 'active',
        addedDate: new Date().toISOString()
    };
    
    res.json({ success: true, account: emailAccount });
});

app.post('/api/emails/:id/test', (req, res) => {
    // Handle email connection test
    const { id } = req.params;
    
    console.log(`Testing email account ${id}`);
    
    // Simulate email test
    setTimeout(() => {
        res.json({ success: true, message: 'Email connection successful' });
    }, 2000);
});

app.post('/api/chat/templates', (req, res) => {
    // Handle message template creation
    const { name, message, trigger } = req.body;
    
    const template = {
        id: Date.now(),
        name,
        message,
        trigger,
        createdDate: new Date().toISOString()
    };
    
    res.json({ success: true, template });
});

app.post('/api/chat/respond', (req, res) => {
    // Handle chat response generation
    const { message, style } = req.body;
    
    // Simple response generation based on style
    let response;
    switch (style) {
        case 'friendly':
            response = `Hey there! ${message} Thanks for reaching out! 😊`;
            break;
        case 'professional':
            response = `Thank you for your message regarding "${message}". I'll get back to you shortly.`;
            break;
        case 'humorous':
            response = `Haha, "${message}" - that's interesting! Let me think about that one 🤔`;
            break;
        default:
            response = `I received your message: "${message}". Let me respond appropriately.`;
    }
    
    res.json({ success: true, response });
});

// WebSocket for real-time updates (using Socket.IO)
const http = require('http');
const socketIo = require('socket.io');

const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    socket.on('learning_data', (data) => {
        console.log('Learning data received:', data);
        // Broadcast to other clients for collaborative learning
        socket.broadcast.emit('learning_update', data);
    });
    
    socket.on('game_status_update', (data) => {
        console.log('Game status update:', data);
        socket.broadcast.emit('game_status_changed', data);
    });
    
    socket.on('task_completed', (data) => {
        console.log('Task completed:', data);
        socket.broadcast.emit('task_update', data);
    });
    
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, message: 'Something went wrong!' });
});

// Serve index.html for root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 AI Game Automation Server running on http://0.0.0.0:${PORT}`);
    console.log('📱 Mobile-optimized web app ready for iPhone and Android!');
    console.log('🎮 Features: Game Learning, Auto Clicker, Task Automation, Chat Bot');
});

module.exports = app;