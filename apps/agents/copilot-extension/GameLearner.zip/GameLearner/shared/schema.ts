import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  url: text("url").notNull(),
  type: text("type").notNull(),
  status: text("status").notNull().default("inactive"), // inactive, learning, active
  learningProgress: integer("learning_progress").default(0),
  patterns: jsonb("patterns").default([]),
  icon: text("icon"),
  lastPlayed: timestamp("last_played"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const accounts = pgTable("accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull(),
  encryptedPassword: text("encrypted_password").notNull(),
  provider: text("provider").notNull(),
  linkedGames: jsonb("linked_games").default([]),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const touchPatterns = pgTable("touch_patterns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id),
  name: text("name").notNull(),
  sequence: jsonb("sequence").notNull(), // Array of {x, y, delay} objects
  confidence: integer("confidence").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const learningData = pgTable("learning_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id),
  x: integer("x").notNull(),
  y: integer("y").notNull(),
  target: text("target"),
  context: text("context").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const autoClickerSessions = pgTable("auto_clicker_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id),
  speed: integer("speed").notNull(),
  repeatCount: integer("repeat_count"), // null for infinite
  isActive: boolean("is_active").default(false),
  clicksPerformed: integer("clicks_performed").default(0),
  targetX: integer("target_x"),
  targetY: integer("target_y"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
  lastPlayed: true,
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
  createdAt: true,
  encryptedPassword: true,
}).extend({
  password: z.string().min(1),
});

export const insertTouchPatternSchema = createInsertSchema(touchPatterns).omit({
  id: true,
  createdAt: true,
});

export const insertLearningDataSchema = createInsertSchema(learningData).omit({
  id: true,
  timestamp: true,
});

export const insertAutoClickerSessionSchema = createInsertSchema(autoClickerSessions).omit({
  id: true,
  createdAt: true,
  clicksPerformed: true,
});

// Types
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;

export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Account = typeof accounts.$inferSelect;

export type InsertTouchPattern = z.infer<typeof insertTouchPatternSchema>;
export type TouchPattern = typeof touchPatterns.$inferSelect;

export type InsertLearningData = z.infer<typeof insertLearningDataSchema>;
export type LearningData = typeof learningData.$inferSelect;

export type InsertAutoClickerSession = z.infer<typeof insertAutoClickerSessionSchema>;
export type AutoClickerSession = typeof autoClickerSessions.$inferSelect;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
