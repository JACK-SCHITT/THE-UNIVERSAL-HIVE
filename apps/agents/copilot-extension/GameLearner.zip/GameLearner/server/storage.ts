import { 
  type User, 
  type InsertUser, 
  type Game, 
  type InsertGame,
  type Account,
  type InsertAccount,
  type TouchPattern,
  type InsertTouchPattern,
  type LearningData,
  type InsertLearningData,
  type AutoClickerSession,
  type InsertAutoClickerSession
} from "@shared/schema";
import { randomUUID } from "crypto";
import crypto from "crypto";

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || crypto.randomBytes(32).toString('hex');

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Games
  getGames(): Promise<Game[]>;
  getGame(id: string): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined>;
  deleteGame(id: string): Promise<boolean>;

  // Accounts
  getAccounts(): Promise<Account[]>;
  getAccount(id: string): Promise<Account | undefined>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: string, updates: Partial<Account>): Promise<Account | undefined>;
  deleteAccount(id: string): Promise<boolean>;

  // Touch Patterns
  getTouchPatterns(gameId?: string): Promise<TouchPattern[]>;
  getTouchPattern(id: string): Promise<TouchPattern | undefined>;
  createTouchPattern(pattern: InsertTouchPattern): Promise<TouchPattern>;
  updateTouchPattern(id: string, updates: Partial<TouchPattern>): Promise<TouchPattern | undefined>;
  deleteTouchPattern(id: string): Promise<boolean>;

  // Learning Data
  getLearningData(gameId?: string): Promise<LearningData[]>;
  createLearningData(data: InsertLearningData): Promise<LearningData>;
  deleteLearningData(gameId: string): Promise<boolean>;

  // Auto Clicker Sessions
  getAutoClickerSessions(): Promise<AutoClickerSession[]>;
  getActiveAutoClickerSession(): Promise<AutoClickerSession | undefined>;
  createAutoClickerSession(session: InsertAutoClickerSession): Promise<AutoClickerSession>;
  updateAutoClickerSession(id: string, updates: Partial<AutoClickerSession>): Promise<AutoClickerSession | undefined>;
  deleteAutoClickerSession(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private games: Map<string, Game>;
  private accounts: Map<string, Account>;
  private touchPatterns: Map<string, TouchPattern>;
  private learningData: Map<string, LearningData>;
  private autoClickerSessions: Map<string, AutoClickerSession>;

  constructor() {
    this.users = new Map();
    this.games = new Map();
    this.accounts = new Map();
    this.touchPatterns = new Map();
    this.learningData = new Map();
    this.autoClickerSessions = new Map();
  }

  private encryptPassword(password: string): string {
    const cipher = crypto.createCipher('aes-256-cbc', ENCRYPTION_KEY);
    let encrypted = cipher.update(password, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
  }

  private decryptPassword(encryptedPassword: string): string {
    const decipher = crypto.createDecipher('aes-256-cbc', ENCRYPTION_KEY);
    let decrypted = decipher.update(encryptedPassword, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Games
  async getGames(): Promise<Game[]> {
    return Array.from(this.games.values());
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = randomUUID();
    const game: Game = {
      ...insertGame,
      id,
      createdAt: new Date(),
      lastPlayed: null,
      patterns: insertGame.patterns || [],
      learningProgress: insertGame.learningProgress || 0,
    };
    this.games.set(id, game);
    return game;
  }

  async updateGame(id: string, updates: Partial<Game>): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;
    
    const updatedGame = { ...game, ...updates };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async deleteGame(id: string): Promise<boolean> {
    return this.games.delete(id);
  }

  // Accounts
  async getAccounts(): Promise<Account[]> {
    return Array.from(this.accounts.values());
  }

  async getAccount(id: string): Promise<Account | undefined> {
    return this.accounts.get(id);
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const id = randomUUID();
    const account: Account = {
      ...insertAccount,
      id,
      encryptedPassword: this.encryptPassword(insertAccount.password),
      createdAt: new Date(),
      linkedGames: insertAccount.linkedGames || [],
      isActive: insertAccount.isActive ?? true,
    };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccount(id: string, updates: Partial<Account>): Promise<Account | undefined> {
    const account = this.accounts.get(id);
    if (!account) return undefined;
    
    const updatedAccount = { ...account, ...updates };
    this.accounts.set(id, updatedAccount);
    return updatedAccount;
  }

  async deleteAccount(id: string): Promise<boolean> {
    return this.accounts.delete(id);
  }

  // Touch Patterns
  async getTouchPatterns(gameId?: string): Promise<TouchPattern[]> {
    const patterns = Array.from(this.touchPatterns.values());
    return gameId ? patterns.filter(p => p.gameId === gameId) : patterns;
  }

  async getTouchPattern(id: string): Promise<TouchPattern | undefined> {
    return this.touchPatterns.get(id);
  }

  async createTouchPattern(insertPattern: InsertTouchPattern): Promise<TouchPattern> {
    const id = randomUUID();
    const pattern: TouchPattern = {
      ...insertPattern,
      id,
      createdAt: new Date(),
      confidence: insertPattern.confidence || 0,
      isActive: insertPattern.isActive ?? true,
    };
    this.touchPatterns.set(id, pattern);
    return pattern;
  }

  async updateTouchPattern(id: string, updates: Partial<TouchPattern>): Promise<TouchPattern | undefined> {
    const pattern = this.touchPatterns.get(id);
    if (!pattern) return undefined;
    
    const updatedPattern = { ...pattern, ...updates };
    this.touchPatterns.set(id, updatedPattern);
    return updatedPattern;
  }

  async deleteTouchPattern(id: string): Promise<boolean> {
    return this.touchPatterns.delete(id);
  }

  // Learning Data
  async getLearningData(gameId?: string): Promise<LearningData[]> {
    const data = Array.from(this.learningData.values());
    return gameId ? data.filter(d => d.gameId === gameId) : data;
  }

  async createLearningData(insertData: InsertLearningData): Promise<LearningData> {
    const id = randomUUID();
    const data: LearningData = {
      ...insertData,
      id,
      timestamp: new Date(),
    };
    this.learningData.set(id, data);
    return data;
  }

  async deleteLearningData(gameId: string): Promise<boolean> {
    const dataToDelete = Array.from(this.learningData.entries())
      .filter(([_, data]) => data.gameId === gameId);
    
    dataToDelete.forEach(([id]) => this.learningData.delete(id));
    return dataToDelete.length > 0;
  }

  // Auto Clicker Sessions
  async getAutoClickerSessions(): Promise<AutoClickerSession[]> {
    return Array.from(this.autoClickerSessions.values());
  }

  async getActiveAutoClickerSession(): Promise<AutoClickerSession | undefined> {
    return Array.from(this.autoClickerSessions.values()).find(s => s.isActive);
  }

  async createAutoClickerSession(insertSession: InsertAutoClickerSession): Promise<AutoClickerSession> {
    const id = randomUUID();
    const session: AutoClickerSession = {
      ...insertSession,
      id,
      createdAt: new Date(),
      clicksPerformed: 0,
      isActive: insertSession.isActive ?? false,
    };
    this.autoClickerSessions.set(id, session);
    return session;
  }

  async updateAutoClickerSession(id: string, updates: Partial<AutoClickerSession>): Promise<AutoClickerSession | undefined> {
    const session = this.autoClickerSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.autoClickerSessions.set(id, updatedSession);
    return updatedSession;
  }

  async deleteAutoClickerSession(id: string): Promise<boolean> {
    return this.autoClickerSessions.delete(id);
  }
}

export const storage = new MemStorage();
