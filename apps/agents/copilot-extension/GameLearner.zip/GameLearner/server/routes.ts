import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertGameSchema, 
  insertAccountSchema, 
  insertTouchPatternSchema, 
  insertLearningDataSchema,
  insertAutoClickerSessionSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('WebSocket client connected');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Games API
  app.get('/api/games', async (req, res) => {
    try {
      const games = await storage.getGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch games' });
    }
  });

  app.post('/api/games', async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(gameData);
      
      broadcast({ type: 'game_created', data: game });
      res.json(game);
    } catch (error) {
      res.status(400).json({ error: 'Invalid game data' });
    }
  });

  app.put('/api/games/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const game = await storage.updateGame(id, updates);
      
      if (!game) {
        return res.status(404).json({ error: 'Game not found' });
      }
      
      broadcast({ type: 'game_updated', data: game });
      res.json(game);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update game' });
    }
  });

  app.delete('/api/games/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteGame(id);
      
      if (!deleted) {
        return res.status(404).json({ error: 'Game not found' });
      }
      
      broadcast({ type: 'game_deleted', data: { id } });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete game' });
    }
  });

  // Accounts API
  app.get('/api/accounts', async (req, res) => {
    try {
      const accounts = await storage.getAccounts();
      // Don't send encrypted passwords to client
      const safeAccounts = accounts.map(({ encryptedPassword, ...account }) => account);
      res.json(safeAccounts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch accounts' });
    }
  });

  app.post('/api/accounts', async (req, res) => {
    try {
      const accountData = insertAccountSchema.parse(req.body);
      const account = await storage.createAccount(accountData);
      
      // Don't send encrypted password to client
      const { encryptedPassword, ...safeAccount } = account;
      
      broadcast({ type: 'account_created', data: safeAccount });
      res.json(safeAccount);
    } catch (error) {
      res.status(400).json({ error: 'Invalid account data' });
    }
  });

  app.delete('/api/accounts/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAccount(id);
      
      if (!deleted) {
        return res.status(404).json({ error: 'Account not found' });
      }
      
      broadcast({ type: 'account_deleted', data: { id } });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete account' });
    }
  });

  // Touch Patterns API
  app.get('/api/touch-patterns', async (req, res) => {
    try {
      const { gameId } = req.query;
      const patterns = await storage.getTouchPatterns(gameId as string);
      res.json(patterns);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch touch patterns' });
    }
  });

  app.post('/api/touch-patterns', async (req, res) => {
    try {
      const patternData = insertTouchPatternSchema.parse(req.body);
      const pattern = await storage.createTouchPattern(patternData);
      
      broadcast({ type: 'pattern_created', data: pattern });
      res.json(pattern);
    } catch (error) {
      res.status(400).json({ error: 'Invalid pattern data' });
    }
  });

  app.delete('/api/touch-patterns/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTouchPattern(id);
      
      if (!deleted) {
        return res.status(404).json({ error: 'Pattern not found' });
      }
      
      broadcast({ type: 'pattern_deleted', data: { id } });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete pattern' });
    }
  });

  // Learning Data API
  app.post('/api/learning-data', async (req, res) => {
    try {
      const learningData = insertLearningDataSchema.parse(req.body);
      const data = await storage.createLearningData(learningData);
      
      broadcast({ type: 'learning_data_recorded', data });
      res.json(data);
    } catch (error) {
      res.status(400).json({ error: 'Invalid learning data' });
    }
  });

  app.get('/api/learning-data', async (req, res) => {
    try {
      const { gameId } = req.query;
      const data = await storage.getLearningData(gameId as string);
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch learning data' });
    }
  });

  // Auto Clicker API
  app.get('/api/auto-clicker/sessions', async (req, res) => {
    try {
      const sessions = await storage.getAutoClickerSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch auto clicker sessions' });
    }
  });

  app.get('/api/auto-clicker/active', async (req, res) => {
    try {
      const session = await storage.getActiveAutoClickerSession();
      res.json(session || null);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch active session' });
    }
  });

  app.post('/api/auto-clicker/start', async (req, res) => {
    try {
      const sessionData = insertAutoClickerSessionSchema.parse({
        ...req.body,
        isActive: true
      });
      
      // Stop any existing active sessions
      const activeSessions = await storage.getAutoClickerSessions();
      for (const session of activeSessions) {
        if (session.isActive) {
          await storage.updateAutoClickerSession(session.id, { isActive: false });
        }
      }
      
      const session = await storage.createAutoClickerSession(sessionData);
      
      broadcast({ type: 'auto_clicker_started', data: session });
      res.json(session);
    } catch (error) {
      res.status(400).json({ error: 'Invalid session data' });
    }
  });

  app.post('/api/auto-clicker/stop', async (req, res) => {
    try {
      const activeSession = await storage.getActiveAutoClickerSession();
      
      if (!activeSession) {
        return res.status(404).json({ error: 'No active session found' });
      }
      
      const updatedSession = await storage.updateAutoClickerSession(activeSession.id, { 
        isActive: false 
      });
      
      broadcast({ type: 'auto_clicker_stopped', data: updatedSession });
      res.json(updatedSession);
    } catch (error) {
      res.status(500).json({ error: 'Failed to stop auto clicker' });
    }
  });

  app.post('/api/auto-clicker/emergency-stop', async (req, res) => {
    try {
      const activeSessions = await storage.getAutoClickerSessions();
      const stoppedSessions = [];
      
      for (const session of activeSessions) {
        if (session.isActive) {
          const stopped = await storage.updateAutoClickerSession(session.id, { isActive: false });
          if (stopped) stoppedSessions.push(stopped);
        }
      }
      
      broadcast({ type: 'emergency_stop_activated', data: { stoppedSessions } });
      res.json({ success: true, stoppedSessions });
    } catch (error) {
      res.status(500).json({ error: 'Failed to execute emergency stop' });
    }
  });

  // Game Learning API
  app.post('/api/games/:id/start-learning', async (req, res) => {
    try {
      const { id } = req.params;
      const game = await storage.updateGame(id, { 
        status: 'learning',
        learningProgress: 0 
      });
      
      if (!game) {
        return res.status(404).json({ error: 'Game not found' });
      }
      
      broadcast({ type: 'learning_started', data: game });
      res.json(game);
    } catch (error) {
      res.status(500).json({ error: 'Failed to start learning' });
    }
  });

  app.post('/api/games/:id/update-progress', async (req, res) => {
    try {
      const { id } = req.params;
      const { progress } = req.body;
      
      const status = progress >= 100 ? 'active' : 'learning';
      const game = await storage.updateGame(id, { 
        learningProgress: progress,
        status,
        lastPlayed: new Date()
      });
      
      if (!game) {
        return res.status(404).json({ error: 'Game not found' });
      }
      
      broadcast({ type: 'learning_progress_updated', data: game });
      res.json(game);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update learning progress' });
    }
  });

  return httpServer;
}
