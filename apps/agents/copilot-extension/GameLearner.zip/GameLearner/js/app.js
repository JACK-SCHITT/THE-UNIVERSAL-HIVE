// AI Game Automation App
class GameAutomationApp {
    constructor() {
        this.games = JSON.parse(localStorage.getItem('games')) || [];
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        this.emails = JSON.parse(localStorage.getItem('emails')) || [];
        this.messageTemplates = JSON.parse(localStorage.getItem('messageTemplates')) || [];
        this.learningData = JSON.parse(localStorage.getItem('learningData')) || [];
        this.autoClickerActive = false;
        this.clickerInterval = null;
        this.learningProgress = 0;
        this.patternsLearned = 0;
        this.accuracy = 0;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadData();
        this.updateUI();
        this.startLearningEngine();
    }

    setupEventListeners() {
        // Form submissions
        document.getElementById('addGameForm').addEventListener('submit', (e) => this.handleAddGame(e));
        document.getElementById('taskForm').addEventListener('submit', (e) => this.handleAddTask(e));
        document.getElementById('emailForm').addEventListener('submit', (e) => this.handleAddEmail(e));

        // Auto clicker controls
        document.getElementById('clickSpeed').addEventListener('input', (e) => this.updateSpeedDisplay(e.target.value));
        document.getElementById('responseStyle').addEventListener('change', (e) => this.handleResponseStyleChange(e.target.value));

        // Screen capture for click detection
        document.addEventListener('click', (e) => this.recordClick(e));
    }

    // Game Management
    handleAddGame(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        
        const game = {
            id: Date.now(),
            name: document.getElementById('gameName').value,
            url: document.getElementById('gameUrl').value,
            type: document.getElementById('gameType').value,
            status: 'inactive',
            learningProgress: 0,
            patterns: [],
            addedDate: new Date().toISOString()
        };

        this.games.push(game);
        this.saveGames();
        this.renderGames();
        this.showNotification(`Game "${game.name}" added successfully!`);
        form.reset();

        // Start learning process for the new game
        setTimeout(() => this.startGameLearning(game.id), 1000);
    }

    startGameLearning(gameId) {
        const game = this.games.find(g => g.id === gameId);
        if (!game) return;

        game.status = 'learning';
        this.saveGames();
        this.renderGames();

        // Simulate learning process
        this.showNotification(`Starting to learn "${game.name}"...`);
        
        // Open game in new window/iframe for learning
        this.openGameForLearning(game);
    }

    openGameForLearning(game) {
        // Create learning overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            color: white;
        `;

        overlay.innerHTML = `
            <h2>Learning Game: ${game.name}</h2>
            <p>AI is analyzing the game interface...</p>
            <div class="loading" style="margin: 1rem;"></div>
            <iframe src="${game.url}" style="width: 90%; height: 70%; border: none; border-radius: 8px;"></iframe>
            <button onclick="this.parentElement.remove()" style="margin-top: 1rem; padding: 0.5rem 1rem; background: #ef4444; color: white; border: none; border-radius: 4px; cursor: pointer;">Close Learning Mode</button>
        `;

        document.body.appendChild(overlay);

        // Simulate learning progress
        let progress = 0;
        const learningInterval = setInterval(() => {
            progress += Math.random() * 10;
            if (progress >= 100) {
                progress = 100;
                clearInterval(learningInterval);
                game.status = 'active';
                game.learningProgress = 100;
                this.saveGames();
                this.renderGames();
                this.showNotification(`"${game.name}" learning complete!`);
            }
            game.learningProgress = Math.min(progress, 100);
            this.saveGames();
            this.renderGames();
        }, 2000);
    }

    // Auto Clicker System
    updateSpeedDisplay(speed) {
        const speedTexts = [
            '', '1 - Normal Human Speed', '2 - Slightly Faster', '3 - Fast',
            '4 - Very Fast', '5 - Rapid', '6 - Super Fast', '7 - Lightning',
            '8 - Extreme', '9 - Superhuman', '10 - 20x Human Speed'
        ];
        document.getElementById('speedValue').textContent = speedTexts[speed];
    }

    toggleAutoClicker() {
        if (this.autoClickerActive) {
            this.stopAutoClicker();
        } else {
            this.startAutoClicker();
        }
    }

    startAutoClicker() {
        const repeatCount = parseInt(document.getElementById('repeatCount').value) || 0;
        const speed = parseInt(document.getElementById('clickSpeed').value);
        const x = parseInt(document.getElementById('clickX').value);
        const y = parseInt(document.getElementById('clickY').value);

        if (!x || !y) {
            this.showNotification('Please set click coordinates first', 'error');
            return;
        }

        this.autoClickerActive = true;
        document.getElementById('clickerStatus').innerHTML = '<i class="fas fa-circle" style="color: #10b981;"></i> Active';
        document.querySelector('[data-testid="btn-start-clicker"]').innerHTML = '<i class="fas fa-pause"></i> Pause';

        const interval = this.calculateClickInterval(speed);
        let clickCount = 0;

        this.clickerInterval = setInterval(() => {
            this.simulateClick(x, y);
            clickCount++;
            
            // Learn from click patterns
            this.recordLearningData({
                x, y, speed, timestamp: Date.now(),
                context: 'auto_click'
            });

            if (repeatCount > 0 && clickCount >= repeatCount) {
                this.stopAutoClicker();
            }
        }, interval);

        this.showNotification('Auto clicker started!');
    }

    stopAutoClicker() {
        this.autoClickerActive = false;
        if (this.clickerInterval) {
            clearInterval(this.clickerInterval);
            this.clickerInterval = null;
        }
        
        document.getElementById('clickerStatus').innerHTML = '<i class="fas fa-circle"></i> Inactive';
        document.querySelector('[data-testid="btn-start-clicker"]').innerHTML = '<i class="fas fa-play"></i> Start Auto Clicker';
        this.showNotification('Auto clicker stopped');
    }

    calculateClickInterval(speed) {
        // Speed 1 = 1000ms (human), Speed 10 = 50ms (20x faster)
        const baseInterval = 1000;
        return Math.max(baseInterval / (speed * 2), 50);
    }

    simulateClick(x, y) {
        // Create visual feedback for click
        const clickIndicator = document.createElement('div');
        clickIndicator.style.cssText = `
            position: fixed;
            left: ${x}px;
            top: ${y}px;
            width: 20px;
            height: 20px;
            background: rgba(37, 99, 235, 0.7);
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            animation: clickPulse 0.3s ease-out;
        `;

        // Add click animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes clickPulse {
                0% { transform: scale(0.5); opacity: 1; }
                100% { transform: scale(2); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
        document.body.appendChild(clickIndicator);

        setTimeout(() => {
            document.body.removeChild(clickIndicator);
        }, 300);

        // Dispatch actual click event
        const element = document.elementFromPoint(x, y);
        if (element) {
            element.click();
        }
    }

    startClickDetection() {
        this.showNotification('Click anywhere to set target position');
        document.body.style.cursor = 'crosshair';
        
        const clickHandler = (e) => {
            e.preventDefault();
            document.getElementById('clickX').value = e.clientX;
            document.getElementById('clickY').value = e.clientY;
            document.body.style.cursor = 'default';
            document.removeEventListener('click', clickHandler, true);
            this.showNotification(`Target set to (${e.clientX}, ${e.clientY})`);
        };

        document.addEventListener('click', clickHandler, true);
    }

    // Learning Engine
    startLearningEngine() {
        setInterval(() => {
            this.processLearningData();
            this.updateLearningProgress();
        }, 5000);
    }

    recordClick(e) {
        // Record all user clicks for learning
        this.recordLearningData({
            x: e.clientX,
            y: e.clientY,
            target: e.target.tagName,
            timestamp: Date.now(),
            context: 'user_click'
        });
    }

    recordLearningData(data) {
        this.learningData.push(data);
        if (this.learningData.length > 1000) {
            this.learningData = this.learningData.slice(-1000); // Keep last 1000 entries
        }
        localStorage.setItem('learningData', JSON.stringify(this.learningData));
    }

    processLearningData() {
        if (this.learningData.length < 10) return;

        // Analyze patterns
        const patterns = this.findClickPatterns();
        this.patternsLearned = patterns.length;
        
        // Calculate accuracy based on pattern consistency
        this.accuracy = Math.min(95, (this.patternsLearned * 10) + Math.random() * 20);
        
        this.updateLearningDisplay();
    }

    findClickPatterns() {
        const patterns = [];
        const recentClicks = this.learningData.slice(-50);
        
        // Simple pattern detection
        for (let i = 0; i < recentClicks.length - 2; i++) {
            const sequence = recentClicks.slice(i, i + 3);
            patterns.push({
                sequence,
                confidence: Math.random() * 100
            });
        }
        
        return patterns.filter(p => p.confidence > 70);
    }

    updateLearningProgress() {
        this.learningProgress = Math.min(100, (this.learningData.length / 100) * 100);
        document.getElementById('learningProgress').style.width = this.learningProgress + '%';
    }

    updateLearningDisplay() {
        document.getElementById('learningStats').textContent = 
            `Patterns Learned: ${this.patternsLearned} | Accuracy: ${Math.round(this.accuracy)}%`;
    }

    // Task Management
    handleAddTask(e) {
        e.preventDefault();
        
        const task = {
            id: Date.now(),
            name: document.getElementById('taskName').value,
            game: document.getElementById('taskGame').value,
            time: document.getElementById('taskTime').value,
            description: document.getElementById('taskDescription').value,
            completed: false,
            createdDate: new Date().toISOString()
        };

        this.tasks.push(task);
        this.saveTasks();
        this.renderTasks();
        this.hideAddTaskForm();
        this.showNotification('Task added successfully!');
        e.target.reset();
    }

    runDailyTasks() {
        const incompleteTasks = this.tasks.filter(t => !t.completed);
        if (incompleteTasks.length === 0) {
            this.showNotification('No pending tasks to run');
            return;
        }

        this.showNotification(`Running ${incompleteTasks.length} daily tasks...`);
        
        incompleteTasks.forEach((task, index) => {
            setTimeout(() => {
                this.executeTask(task);
            }, index * 2000);
        });
    }

    executeTask(task) {
        const game = this.games.find(g => g.id == task.game);
        
        if (game) {
            this.showNotification(`Executing: ${task.name} in ${game.name}`);
            
            // Simulate task execution
            setTimeout(() => {
                task.completed = true;
                this.saveTasks();
                this.renderTasks();
                this.showNotification(`Completed: ${task.name}`);
            }, 3000);
        } else {
            this.showNotification(`Cannot execute ${task.name}: Game not found`, 'error');
        }
    }

    // Email Management
    handleAddEmail(e) {
        e.preventDefault();
        
        const email = {
            id: Date.now(),
            address: document.getElementById('emailAddress').value,
            password: document.getElementById('emailPassword').value, // In real app, encrypt this
            provider: document.getElementById('emailProvider').value,
            status: 'active',
            addedDate: new Date().toISOString()
        };

        this.emails.push(email);
        this.saveEmails();
        this.renderEmails();
        this.hideAddEmailForm();
        this.showNotification('Email account added successfully!');
        e.target.reset();
    }

    // Chat Bot System
    handleResponseStyleChange(style) {
        const customGroup = document.getElementById('customStyleGroup');
        if (style === 'custom') {
            customGroup.style.display = 'block';
        } else {
            customGroup.style.display = 'none';
        }
    }

    addMessageTemplate() {
        const template = {
            id: Date.now(),
            name: 'New Template',
            message: 'Hello! How are you?',
            trigger: 'greeting'
        };

        this.messageTemplates.push(template);
        this.saveMessageTemplates();
        this.renderMessageTemplates();
    }

    // UI Management
    renderGames() {
        const container = document.getElementById('gamesList');
        if (this.games.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">No games added yet</p>';
            return;
        }

        container.innerHTML = this.games.map(game => `
            <div class="game-item" data-testid="game-item-${game.id}">
                <div class="game-icon">
                    <i class="fas fa-gamepad"></i>
                </div>
                <div class="game-info">
                    <div class="game-name">${game.name}</div>
                    <div class="game-status">
                        <span class="status-indicator status-${game.status}">
                            <i class="fas fa-circle"></i> ${game.status.charAt(0).toUpperCase() + game.status.slice(1)}
                        </span>
                    </div>
                    <div style="margin-top: 0.5rem;">
                        <small>Learning Progress: ${Math.round(game.learningProgress || 0)}%</small>
                        <div class="progress-bar" style="height: 4px; margin-top: 4px;">
                            <div class="progress-fill" style="width: ${game.learningProgress || 0}%"></div>
                        </div>
                    </div>
                </div>
                <div class="game-actions">
                    <button class="btn btn-primary btn-small" onclick="app.openGame('${game.id}')" data-testid="btn-open-game-${game.id}">
                        <i class="fas fa-play"></i> Open
                    </button>
                    <button class="btn btn-outline btn-small" onclick="app.deleteGame('${game.id}')" data-testid="btn-delete-game-${game.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');

        // Update task game options
        this.updateTaskGameOptions();
    }

    renderTasks() {
        const container = document.getElementById('tasksList');
        if (this.tasks.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">No tasks scheduled</p>';
            return;
        }

        container.innerHTML = this.tasks.map(task => {
            const game = this.games.find(g => g.id == task.game);
            return `
                <div class="task-item" data-testid="task-item-${task.id}">
                    <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} 
                           onchange="app.toggleTask('${task.id}')" data-testid="checkbox-task-${task.id}">
                    <div class="task-content">
                        <div style="font-weight: 600;">${task.name}</div>
                        <div style="font-size: 0.875rem; color: var(--text-secondary);">
                            Game: ${game ? game.name : 'Unknown'} | Time: ${task.time}
                        </div>
                        <div style="font-size: 0.875rem; margin-top: 0.25rem;">${task.description}</div>
                    </div>
                    <button class="btn btn-danger btn-small" onclick="app.deleteTask('${task.id}')" data-testid="btn-delete-task-${task.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }).join('');
    }

    renderEmails() {
        const container = document.getElementById('emailsList');
        if (this.emails.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">No email accounts added</p>';
            return;
        }

        container.innerHTML = this.emails.map(email => `
            <div class="game-item" data-testid="email-item-${email.id}">
                <div class="game-icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <div class="game-info">
                    <div class="game-name">${email.address}</div>
                    <div class="game-status">
                        <span class="status-indicator status-${email.status}">
                            <i class="fas fa-circle"></i> ${email.status.charAt(0).toUpperCase() + email.status.slice(1)}
                        </span>
                    </div>
                    <div style="font-size: 0.875rem; color: var(--text-secondary);">
                        Provider: ${email.provider.charAt(0).toUpperCase() + email.provider.slice(1)}
                    </div>
                </div>
                <div class="game-actions">
                    <button class="btn btn-primary btn-small" onclick="app.testEmail('${email.id}')" data-testid="btn-test-email-${email.id}">
                        <i class="fas fa-check"></i> Test
                    </button>
                    <button class="btn btn-outline btn-small" onclick="app.deleteEmail('${email.id}')" data-testid="btn-delete-email-${email.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    renderMessageTemplates() {
        const container = document.getElementById('messageTemplates');
        container.innerHTML = this.messageTemplates.map(template => `
            <div class="message-template" data-testid="template-${template.id}">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <strong>${template.name}</strong>
                    <button class="btn btn-danger btn-small" onclick="app.deleteTemplate('${template.id}')" data-testid="btn-delete-template-${template.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div style="margin-bottom: 0.5rem;">${template.message}</div>
                <small>Trigger: ${template.trigger}</small>
            </div>
        `).join('');
    }

    updateTaskGameOptions() {
        const select = document.getElementById('taskGame');
        select.innerHTML = '<option value="">Select a game</option>' + 
            this.games.map(game => `<option value="${game.id}">${game.name}</option>`).join('');
    }

    // Utility Functions
    openGame(gameId) {
        const game = this.games.find(g => g.id == gameId);
        if (game) {
            window.open(game.url, '_blank');
            this.showNotification(`Opening ${game.name}...`);
        }
    }

    deleteGame(gameId) {
        if (confirm('Are you sure you want to delete this game?')) {
            this.games = this.games.filter(g => g.id != gameId);
            this.saveGames();
            this.renderGames();
            this.showNotification('Game deleted');
        }
    }

    toggleTask(taskId) {
        const task = this.tasks.find(t => t.id == taskId);
        if (task) {
            task.completed = !task.completed;
            this.saveTasks();
        }
    }

    deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id != taskId);
            this.saveTasks();
            this.renderTasks();
            this.showNotification('Task deleted');
        }
    }

    testEmail(emailId) {
        const email = this.emails.find(e => e.id == emailId);
        if (email) {
            this.showNotification(`Testing connection to ${email.address}...`);
            // Simulate email test
            setTimeout(() => {
                this.showNotification(`${email.address} connection successful!`);
            }, 2000);
        }
    }

    deleteEmail(emailId) {
        if (confirm('Are you sure you want to delete this email account?')) {
            this.emails = this.emails.filter(e => e.id != emailId);
            this.saveEmails();
            this.renderEmails();
            this.showNotification('Email account deleted');
        }
    }

    deleteTemplate(templateId) {
        this.messageTemplates = this.messageTemplates.filter(t => t.id != templateId);
        this.saveMessageTemplates();
        this.renderMessageTemplates();
        this.showNotification('Template deleted');
    }

    showAddTaskForm() {
        document.getElementById('addTaskForm').classList.remove('hidden');
    }

    hideAddTaskForm() {
        document.getElementById('addTaskForm').classList.add('hidden');
    }

    showAddEmailForm() {
        document.getElementById('addEmailForm').classList.remove('hidden');
    }

    hideAddEmailForm() {
        document.getElementById('addEmailForm').classList.add('hidden');
    }

    refreshGames() {
        this.renderGames();
        this.showNotification('Games refreshed');
    }

    // Data Persistence
    saveGames() {
        localStorage.setItem('games', JSON.stringify(this.games));
    }

    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    saveEmails() {
        localStorage.setItem('emails', JSON.stringify(this.emails));
    }

    saveMessageTemplates() {
        localStorage.setItem('messageTemplates', JSON.stringify(this.messageTemplates));
    }

    loadData() {
        this.renderGames();
        this.renderTasks();
        this.renderEmails();
        this.renderMessageTemplates();
    }

    updateUI() {
        this.updateLearningDisplay();
        this.updateLearningProgress();
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        const text = document.getElementById('notificationText');
        
        text.textContent = message;
        notification.className = `notification ${type} show`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Global Functions
function showTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabName).classList.add('active');
    
    // Add active class to selected nav tab
    document.querySelector(`[data-testid="tab-${tabName}"]`).classList.add('active');
}

function toggleTheme() {
    document.body.classList.toggle('dark');
    const isDark = document.body.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    const themeIcon = document.querySelector('.theme-toggle i');
    themeIcon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
}

// Initialize theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    document.body.classList.add('dark');
    document.querySelector('.theme-toggle i').className = 'fas fa-sun';
}

// Initialize app
const app = new GameAutomationApp();